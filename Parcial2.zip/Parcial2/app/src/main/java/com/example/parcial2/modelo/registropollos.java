package com.example.parcial2.modelo;

public class registropollos {

    public registropollos(String fechaDia, int comida, Double precioDef) {
        this.fechaDia = fechaDia;
        this.precioDef = precioDef;
        this.comida = comida;
    }

    public String getFechaDia() {
        return fechaDia;
    }

    public void setFechaDia(String fechaDia) {
        this.fechaDia = fechaDia;
    }

    public Double getPrecioDef() {
        return precioDef;
    }

    public void setPrecioDef(Double precioDef) {
        this.precioDef = precioDef;
    }

    public int getComida() {
        return comida;
    }

    public void setComida(int comida) {
        this.comida = comida;
    }

    public registropollos(){
    }

    private String fechaDia;
    private Double precioDef;
    private int comida;
}
