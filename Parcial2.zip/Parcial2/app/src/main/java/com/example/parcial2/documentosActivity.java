package com.example.parcial2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class documentosActivity extends AppCompatActivity {

    private ListView listviewlib;
    private ArrayList<String> documentos;
    private StorageReference mstorageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_documentos);

        listviewlib= findViewById(R.id.viewdoc);
        documentos= new ArrayList<>();

        //inicializar el objeto de firebase storage
        mstorageRef= FirebaseStorage.getInstance().getReference();

        //traer los datos del bucket
        StorageReference ref= mstorageRef.child("documentos");
        ref.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>() {
            @Override
            public void onSuccess(ListResult listResult) {
                Log.e("documentos", "entrando a recuperar documentos");
                for(StorageReference item : listResult.getItems()){
                    documentos.add(item.getName()+"");
                    Log.e("documentos: -->", item.getPath() + "..." + item.getName());
                }
                //configurar adaptador de la lista
                ArrayAdapter<String> adapter= new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, documentos);
                listviewlib.setAdapter(adapter);
            }
        }).addOnFailureListener((e) -> {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(documentosActivity.this);
            builder1.setMessage("Ha ocurrido un error al cargar los documentos, Por favor revise la conexion a internet");
            builder1.setCancelable(true);
            builder1.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });
            AlertDialog alert1 = builder1.create();
            alert1.show();
        });
    }
}