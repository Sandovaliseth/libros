package com.example.parcial2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.parcial2.modelo.registropollos;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class bdatosActivity extends AppCompatActivity {

    private CalendarView calendarview;
    private TextView totalpollos, most_comida, most_precio, fecha;
    private EditText cant_pollos, cant_comida, precio;
    private Button insertar;

    private FirebaseDatabase database;
    private DatabaseReference myRef;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bdatos);

        calendarview = findViewById(R.id.calendarView);
        totalpollos = findViewById(R.id.totalpollos);
        most_comida = findViewById(R.id.most_comida);
        most_precio = findViewById(R.id.most_precio);
        fecha = findViewById(R.id.fecha);
        cant_pollos = findViewById(R.id.cant_pollos);
        cant_comida = findViewById(R.id.cant_comida);
        precio = findViewById(R.id.precio);
        insertar = findViewById(R.id.insertar);

        auth = FirebaseAuth.getInstance();

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("registrar_pollos");

        calendarview.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayofmonth) {
                String fechaseleccionada = dayofmonth + "-" + month + "-" + year;
                myRef.child(auth.getCurrentUser().getUid()).child(fechaseleccionada).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        registropollos registro_temp = dataSnapshot.getValue(registropollos.class);
                        if (registro_temp != null) {
                            most_comida.setText(registro_temp.getComida() + "");
                            most_precio.setText(registro_temp.getPrecioDef() + "");
                            fecha.setText(registro_temp.getFechaDia());
                        } else {
                            fecha.setText(fechaseleccionada);
                            most_comida.setText(0 + "");
                            most_precio.setText(0 + "");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                fecha.setText(fechaseleccionada);
                most_comida.setText(cant_comida.getText());
                most_precio.setText(precio.getText());
            }
        });

        insertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarpollos(fecha.getText().toString(), Integer.parseInt(cant_comida.getText().toString() + ""), Double.parseDouble(precio.getText().toString() + ""));
            }
        });
    }

    public void guardarpollos(String fechas, Integer comidap, Double precios) {
        registropollos registropollos = new registropollos(fechas, comidap, precios);
        if (auth.getCurrentUser() != null) {
            myRef.child(auth.getCurrentUser().getUid()).child(fechas).setValue(registropollos).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void avoid) {
                    Toast.makeText(bdatosActivity.this, "Se ha guardado correctamente", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(bdatosActivity.this, "Erros, no se ha podido guardar", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}